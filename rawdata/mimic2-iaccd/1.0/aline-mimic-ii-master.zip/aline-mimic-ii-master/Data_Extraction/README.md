Data Extraction Folder 
=======================

This folder is for all the codes related to data extraction.

This folder contains the following subfolder and files (brief description for each file should be given)

/
Readme.md	read me file for the folder 
