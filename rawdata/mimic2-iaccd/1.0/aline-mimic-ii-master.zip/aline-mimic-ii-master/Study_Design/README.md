Study Design Folder 
=======================

This folder is to document the evolution of the study design. The study design report and the continuous design meeting minutes should be archived here.

This folder contains the following subfolder and files (brief description for each file should be given)

/
Readme.md	read me file for the folder 
