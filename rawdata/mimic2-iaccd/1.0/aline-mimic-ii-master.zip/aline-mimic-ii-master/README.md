A-line project with MIMIC-II data  
=======================  

A template repo for clinical studies  

It contains the following folders and files:  

File/folder  | Description
--- | ---
Readme.md | This readme file  
Study_Design/  | Folder to archive all documentations related to study design  
Data_Extraction/ | Folder to archive all data extraction codes  
Data_Analysis/ | Folder to archive all data analysis codes  
Figures_Tables/ | Folder to archive generated figures and tables  
Reports_Publications/ | Folder to archive related reports and manuscripts  
